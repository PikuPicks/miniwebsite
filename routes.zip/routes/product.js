const express = require('express');
const router = express.Router();
const productController = require('../controllers/product');

// CREATE Product
router.post('/product', productController.addProduct);

// READ All Product
router.get('/product', productController.getAllproducts);
router.get('/product/:id', productController.getProductById);

// UPDATE product
router.put('/product/:id', productController.editProduct);

// DELETE User
router.delete('/product/:id', productController.deleteProduct);

module.exports = router;
