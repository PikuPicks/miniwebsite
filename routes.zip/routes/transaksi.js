const express = require('express');
const router = express.Router();
const transaksiController = require('../controllers/transaksi');

router.post('/transaksi', transaksiController.createTransaksi);
router.get('/transaksi', transaksiController.getAllTransaksi);
router.put('/transaksi/:id', transaksiController.updateTransaksi);
router.delete('/transaksi/:id', transaksiController.deleteTransaksi);

module.exports = router;
