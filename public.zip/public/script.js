document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username_regist').value;
    const password = document.getElementById('password_regist').value;

    console.log('Form submitted:', { username, password });

    try {
        const response = await fetch('http://localhost:3000/api/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        console.log('Response status:', response.status);
        const data = await response.json();
        console.log('Response data:', data);
    } catch (error) {
        console.error('Error submitting form:', error);
    }
});


document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username_login').value;
    const password = document.getElementById('password_login').value;

    console.log('Login form submitted:', { username, password });

    try {
        const response = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        console.log('Response status:', response.status);
        const data = await response.json();
        console.log('Response data:', data);

        if (data.message === "Login successful" && data.user) {
            alert(`Login successful! Welcome, ${data.user.username}`);
            console.log('Redirecting to add-product.html...');
            window.location.href = 'add-product.html';
        } else {
            alert('Invalid credentials. Please try again.');
        }
    } catch (error) {
        console.error('Error during login:', error.message);
        alert(`Error: ${error.message}`);
    }
});

